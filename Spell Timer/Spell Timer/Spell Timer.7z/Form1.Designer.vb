﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.timerlabel1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.role1 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.spellnamelabel17 = New System.Windows.Forms.Label()
        Me.spellnamelabel16 = New System.Windows.Forms.Label()
        Me.Startbutton16 = New System.Windows.Forms.Button()
        Me.Stopbutton17 = New System.Windows.Forms.Button()
        Me.timerlabel16 = New System.Windows.Forms.Label()
        Me.Rewindbutton17 = New System.Windows.Forms.Button()
        Me.Rewindbutton16 = New System.Windows.Forms.Button()
        Me.timerlabel17 = New System.Windows.Forms.Label()
        Me.Stopbutton16 = New System.Windows.Forms.Button()
        Me.Startbutton17 = New System.Windows.Forms.Button()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.spellnamelabel15 = New System.Windows.Forms.Label()
        Me.spellnamelabel14 = New System.Windows.Forms.Label()
        Me.Stopbutton15 = New System.Windows.Forms.Button()
        Me.Rewindbutton15 = New System.Windows.Forms.Button()
        Me.timerlabel15 = New System.Windows.Forms.Label()
        Me.Startbutton15 = New System.Windows.Forms.Button()
        Me.spellnamelabel13 = New System.Windows.Forms.Label()
        Me.Startbutton13 = New System.Windows.Forms.Button()
        Me.Stopbutton14 = New System.Windows.Forms.Button()
        Me.timerlabel13 = New System.Windows.Forms.Label()
        Me.Rewindbutton14 = New System.Windows.Forms.Button()
        Me.Rewindbutton13 = New System.Windows.Forms.Button()
        Me.timerlabel14 = New System.Windows.Forms.Label()
        Me.Stopbutton13 = New System.Windows.Forms.Button()
        Me.Startbutton14 = New System.Windows.Forms.Button()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.spellnamelabel12 = New System.Windows.Forms.Label()
        Me.spellnamelabel11 = New System.Windows.Forms.Label()
        Me.Stopbutton12 = New System.Windows.Forms.Button()
        Me.Rewindbutton12 = New System.Windows.Forms.Button()
        Me.timerlabel12 = New System.Windows.Forms.Label()
        Me.Startbutton12 = New System.Windows.Forms.Button()
        Me.spellnamelabel10 = New System.Windows.Forms.Label()
        Me.Startbutton10 = New System.Windows.Forms.Button()
        Me.Stopbutton11 = New System.Windows.Forms.Button()
        Me.timerlabel10 = New System.Windows.Forms.Label()
        Me.Rewindbutton11 = New System.Windows.Forms.Button()
        Me.Rewindbutton10 = New System.Windows.Forms.Button()
        Me.timerlabel11 = New System.Windows.Forms.Label()
        Me.Stopbutton10 = New System.Windows.Forms.Button()
        Me.Startbutton11 = New System.Windows.Forms.Button()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Role5 = New System.Windows.Forms.Label()
        Me.spellnamelabel9 = New System.Windows.Forms.Label()
        Me.Startbutton8 = New System.Windows.Forms.Button()
        Me.Stopbutton9 = New System.Windows.Forms.Button()
        Me.timerlabel8 = New System.Windows.Forms.Label()
        Me.Rewindbutton9 = New System.Windows.Forms.Button()
        Me.Rewindbutton8 = New System.Windows.Forms.Button()
        Me.timerlabel9 = New System.Windows.Forms.Label()
        Me.Stopbutton8 = New System.Windows.Forms.Button()
        Me.Startbutton9 = New System.Windows.Forms.Button()
        Me.spellnamelabel8 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Role4 = New System.Windows.Forms.Label()
        Me.spellnamelabel7 = New System.Windows.Forms.Label()
        Me.Startbutton6 = New System.Windows.Forms.Button()
        Me.Stopbutton7 = New System.Windows.Forms.Button()
        Me.timerlabel6 = New System.Windows.Forms.Label()
        Me.Rewindbutton7 = New System.Windows.Forms.Button()
        Me.Rewindbutton6 = New System.Windows.Forms.Button()
        Me.timerlabel7 = New System.Windows.Forms.Label()
        Me.Stopbutton6 = New System.Windows.Forms.Button()
        Me.Startbutton7 = New System.Windows.Forms.Button()
        Me.spellnamelabel6 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Role3 = New System.Windows.Forms.Label()
        Me.spellnamelabel5 = New System.Windows.Forms.Label()
        Me.Startbutton4 = New System.Windows.Forms.Button()
        Me.Stopbutton5 = New System.Windows.Forms.Button()
        Me.timerlabel4 = New System.Windows.Forms.Label()
        Me.Rewindbutton5 = New System.Windows.Forms.Button()
        Me.Rewindbutton4 = New System.Windows.Forms.Button()
        Me.timerlabel5 = New System.Windows.Forms.Label()
        Me.Stopbutton4 = New System.Windows.Forms.Button()
        Me.Startbutton5 = New System.Windows.Forms.Button()
        Me.spellnamelabel4 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Role2 = New System.Windows.Forms.Label()
        Me.Startbutton3 = New System.Windows.Forms.Button()
        Me.timerlabel3 = New System.Windows.Forms.Label()
        Me.Rewindbutton3 = New System.Windows.Forms.Button()
        Me.Stopbutton3 = New System.Windows.Forms.Button()
        Me.spellnamelabel3 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.spellnamelabel2 = New System.Windows.Forms.Label()
        Me.Startbutton1 = New System.Windows.Forms.Button()
        Me.Stopbutton2 = New System.Windows.Forms.Button()
        Me.Rewindbutton2 = New System.Windows.Forms.Button()
        Me.Rewindbutton1 = New System.Windows.Forms.Button()
        Me.timerlabel2 = New System.Windows.Forms.Label()
        Me.Stopbutton1 = New System.Windows.Forms.Button()
        Me.Startbutton2 = New System.Windows.Forms.Button()
        Me.spellnamelabel1 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Ioniancheckbox2 = New System.Windows.Forms.CheckBox()
        Me.Insightcheckbox2 = New System.Windows.Forms.CheckBox()
        Me.Spellcombobox1 = New System.Windows.Forms.ComboBox()
        Me.Insightcheckbox1 = New System.Windows.Forms.CheckBox()
        Me.Ioniancheckbox1 = New System.Windows.Forms.CheckBox()
        Me.Spellcombobox2 = New System.Windows.Forms.ComboBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Spellcombobox3 = New System.Windows.Forms.ComboBox()
        Me.Insightcheckbox3 = New System.Windows.Forms.CheckBox()
        Me.Ioniancheckbox3 = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Insightcheckbox5 = New System.Windows.Forms.CheckBox()
        Me.Ioniancheckbox5 = New System.Windows.Forms.CheckBox()
        Me.Spellcombobox4 = New System.Windows.Forms.ComboBox()
        Me.Insightcheckbox4 = New System.Windows.Forms.CheckBox()
        Me.Ioniancheckbox4 = New System.Windows.Forms.CheckBox()
        Me.Spellcombobox5 = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Insightcheckbox7 = New System.Windows.Forms.CheckBox()
        Me.Ioniancheckbox7 = New System.Windows.Forms.CheckBox()
        Me.Spellcombobox6 = New System.Windows.Forms.ComboBox()
        Me.Insightcheckbox6 = New System.Windows.Forms.CheckBox()
        Me.Ioniancheckbox6 = New System.Windows.Forms.CheckBox()
        Me.Spellcombobox7 = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Insightcheckbox9 = New System.Windows.Forms.CheckBox()
        Me.Ioniancheckbox9 = New System.Windows.Forms.CheckBox()
        Me.Spellcombobox8 = New System.Windows.Forms.ComboBox()
        Me.Insightcheckbox8 = New System.Windows.Forms.CheckBox()
        Me.Ioniancheckbox8 = New System.Windows.Forms.CheckBox()
        Me.Spellcombobox9 = New System.Windows.Forms.ComboBox()
        Me.setting2 = New System.Windows.Forms.Label()
        Me.setting1 = New System.Windows.Forms.Label()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer6 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer7 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer8 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer9 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer10 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer11 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer12 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer13 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer14 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer15 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer16 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer17 = New System.Windows.Forms.Timer(Me.components)
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'timerlabel1
        '
        Me.timerlabel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel1.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel1.Location = New System.Drawing.Point(69, 9)
        Me.timerlabel1.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel1.Name = "timerlabel1"
        Me.timerlabel1.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel1.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel1.TabIndex = 0
        Me.timerlabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        '
        'role1
        '
        Me.role1.AutoSize = True
        Me.role1.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.role1.Location = New System.Drawing.Point(2, 12)
        Me.role1.Name = "role1"
        Me.role1.Size = New System.Drawing.Size(24, 8)
        Me.role1.TabIndex = 5
        Me.role1.Text = "TOP"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Font = New System.Drawing.Font("Gulim", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(6, 8)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(201, 430)
        Me.TabControl1.TabIndex = 9
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.GroupBox13)
        Me.TabPage1.Controls.Add(Me.GroupBox12)
        Me.TabPage1.Controls.Add(Me.GroupBox11)
        Me.TabPage1.Controls.Add(Me.GroupBox10)
        Me.TabPage1.Controls.Add(Me.GroupBox9)
        Me.TabPage1.Controls.Add(Me.GroupBox8)
        Me.TabPage1.Controls.Add(Me.GroupBox7)
        Me.TabPage1.Controls.Add(Me.GroupBox6)
        Me.TabPage1.Font = New System.Drawing.Font("Gulim", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(0)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(193, 404)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TIMER"
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.spellnamelabel17)
        Me.GroupBox13.Controls.Add(Me.spellnamelabel16)
        Me.GroupBox13.Controls.Add(Me.Startbutton16)
        Me.GroupBox13.Controls.Add(Me.Stopbutton17)
        Me.GroupBox13.Controls.Add(Me.timerlabel16)
        Me.GroupBox13.Controls.Add(Me.Rewindbutton17)
        Me.GroupBox13.Controls.Add(Me.Rewindbutton16)
        Me.GroupBox13.Controls.Add(Me.timerlabel17)
        Me.GroupBox13.Controls.Add(Me.Stopbutton16)
        Me.GroupBox13.Controls.Add(Me.Startbutton17)
        Me.GroupBox13.Location = New System.Drawing.Point(6, 353)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(170, 46)
        Me.GroupBox13.TabIndex = 21
        Me.GroupBox13.TabStop = False
        '
        'spellnamelabel17
        '
        Me.spellnamelabel17.AutoSize = True
        Me.spellnamelabel17.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel17.Location = New System.Drawing.Point(2, 31)
        Me.spellnamelabel17.Name = "spellnamelabel17"
        Me.spellnamelabel17.Size = New System.Drawing.Size(64, 8)
        Me.spellnamelabel17.TabIndex = 17
        Me.spellnamelabel17.Text = "SCUTTLER 2"
        '
        'spellnamelabel16
        '
        Me.spellnamelabel16.AutoSize = True
        Me.spellnamelabel16.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel16.Location = New System.Drawing.Point(2, 12)
        Me.spellnamelabel16.Name = "spellnamelabel16"
        Me.spellnamelabel16.Size = New System.Drawing.Size(64, 8)
        Me.spellnamelabel16.TabIndex = 5
        Me.spellnamelabel16.Text = "SCUTTLER 1"
        '
        'Startbutton16
        '
        Me.Startbutton16.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton16.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton16.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton16.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton16.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton16.Location = New System.Drawing.Point(108, 8)
        Me.Startbutton16.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton16.Name = "Startbutton16"
        Me.Startbutton16.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton16.TabIndex = 1
        Me.Startbutton16.UseVisualStyleBackColor = False
        '
        'Stopbutton17
        '
        Me.Stopbutton17.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton17.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton17.Location = New System.Drawing.Point(149, 27)
        Me.Stopbutton17.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton17.Name = "Stopbutton17"
        Me.Stopbutton17.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton17.TabIndex = 15
        Me.Stopbutton17.UseVisualStyleBackColor = True
        '
        'timerlabel16
        '
        Me.timerlabel16.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel16.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel16.Location = New System.Drawing.Point(69, 9)
        Me.timerlabel16.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel16.Name = "timerlabel16"
        Me.timerlabel16.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel16.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel16.TabIndex = 0
        Me.timerlabel16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Rewindbutton17
        '
        Me.Rewindbutton17.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton17.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton17.Location = New System.Drawing.Point(128, 27)
        Me.Rewindbutton17.Name = "Rewindbutton17"
        Me.Rewindbutton17.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton17.TabIndex = 14
        Me.Rewindbutton17.UseVisualStyleBackColor = True
        '
        'Rewindbutton16
        '
        Me.Rewindbutton16.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton16.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton16.Location = New System.Drawing.Point(128, 8)
        Me.Rewindbutton16.Name = "Rewindbutton16"
        Me.Rewindbutton16.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton16.TabIndex = 9
        Me.Rewindbutton16.UseVisualStyleBackColor = True
        '
        'timerlabel17
        '
        Me.timerlabel17.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel17.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel17.Location = New System.Drawing.Point(69, 28)
        Me.timerlabel17.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel17.Name = "timerlabel17"
        Me.timerlabel17.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel17.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel17.TabIndex = 12
        Me.timerlabel17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Stopbutton16
        '
        Me.Stopbutton16.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton16.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton16.Location = New System.Drawing.Point(149, 8)
        Me.Stopbutton16.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton16.Name = "Stopbutton16"
        Me.Stopbutton16.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton16.TabIndex = 10
        Me.Stopbutton16.UseVisualStyleBackColor = True
        '
        'Startbutton17
        '
        Me.Startbutton17.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton17.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton17.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton17.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton17.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton17.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton17.Location = New System.Drawing.Point(108, 27)
        Me.Startbutton17.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton17.Name = "Startbutton17"
        Me.Startbutton17.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton17.TabIndex = 13
        Me.Startbutton17.UseVisualStyleBackColor = False
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.spellnamelabel15)
        Me.GroupBox12.Controls.Add(Me.spellnamelabel14)
        Me.GroupBox12.Controls.Add(Me.Stopbutton15)
        Me.GroupBox12.Controls.Add(Me.Rewindbutton15)
        Me.GroupBox12.Controls.Add(Me.timerlabel15)
        Me.GroupBox12.Controls.Add(Me.Startbutton15)
        Me.GroupBox12.Controls.Add(Me.spellnamelabel13)
        Me.GroupBox12.Controls.Add(Me.Startbutton13)
        Me.GroupBox12.Controls.Add(Me.Stopbutton14)
        Me.GroupBox12.Controls.Add(Me.timerlabel13)
        Me.GroupBox12.Controls.Add(Me.Rewindbutton14)
        Me.GroupBox12.Controls.Add(Me.Rewindbutton13)
        Me.GroupBox12.Controls.Add(Me.timerlabel14)
        Me.GroupBox12.Controls.Add(Me.Stopbutton13)
        Me.GroupBox12.Controls.Add(Me.Startbutton14)
        Me.GroupBox12.Location = New System.Drawing.Point(6, 288)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(170, 64)
        Me.GroupBox12.TabIndex = 22
        Me.GroupBox12.TabStop = False
        '
        'spellnamelabel15
        '
        Me.spellnamelabel15.AutoSize = True
        Me.spellnamelabel15.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel15.Location = New System.Drawing.Point(2, 49)
        Me.spellnamelabel15.Name = "spellnamelabel15"
        Me.spellnamelabel15.Size = New System.Drawing.Size(44, 8)
        Me.spellnamelabel15.TabIndex = 23
        Me.spellnamelabel15.Text = "GOLEMS"
        '
        'spellnamelabel14
        '
        Me.spellnamelabel14.AutoSize = True
        Me.spellnamelabel14.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel14.Location = New System.Drawing.Point(2, 31)
        Me.spellnamelabel14.Name = "spellnamelabel14"
        Me.spellnamelabel14.Size = New System.Drawing.Size(48, 8)
        Me.spellnamelabel14.TabIndex = 22
        Me.spellnamelabel14.Text = "RAPTORS"
        '
        'Stopbutton15
        '
        Me.Stopbutton15.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton15.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton15.Location = New System.Drawing.Point(149, 45)
        Me.Stopbutton15.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton15.Name = "Stopbutton15"
        Me.Stopbutton15.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton15.TabIndex = 20
        Me.Stopbutton15.UseVisualStyleBackColor = True
        '
        'Rewindbutton15
        '
        Me.Rewindbutton15.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton15.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton15.Location = New System.Drawing.Point(128, 45)
        Me.Rewindbutton15.Name = "Rewindbutton15"
        Me.Rewindbutton15.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton15.TabIndex = 19
        Me.Rewindbutton15.UseVisualStyleBackColor = True
        '
        'timerlabel15
        '
        Me.timerlabel15.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel15.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel15.Location = New System.Drawing.Point(69, 46)
        Me.timerlabel15.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel15.Name = "timerlabel15"
        Me.timerlabel15.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel15.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel15.TabIndex = 17
        Me.timerlabel15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Startbutton15
        '
        Me.Startbutton15.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton15.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton15.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton15.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton15.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton15.Location = New System.Drawing.Point(108, 45)
        Me.Startbutton15.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton15.Name = "Startbutton15"
        Me.Startbutton15.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton15.TabIndex = 18
        Me.Startbutton15.UseVisualStyleBackColor = False
        '
        'spellnamelabel13
        '
        Me.spellnamelabel13.AutoSize = True
        Me.spellnamelabel13.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel13.Location = New System.Drawing.Point(2, 12)
        Me.spellnamelabel13.Name = "spellnamelabel13"
        Me.spellnamelabel13.Size = New System.Drawing.Size(24, 8)
        Me.spellnamelabel13.TabIndex = 5
        Me.spellnamelabel13.Text = "RED"
        '
        'Startbutton13
        '
        Me.Startbutton13.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton13.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton13.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton13.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton13.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton13.Location = New System.Drawing.Point(108, 8)
        Me.Startbutton13.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton13.Name = "Startbutton13"
        Me.Startbutton13.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton13.TabIndex = 1
        Me.Startbutton13.UseVisualStyleBackColor = False
        '
        'Stopbutton14
        '
        Me.Stopbutton14.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton14.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton14.Location = New System.Drawing.Point(149, 27)
        Me.Stopbutton14.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton14.Name = "Stopbutton14"
        Me.Stopbutton14.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton14.TabIndex = 15
        Me.Stopbutton14.UseVisualStyleBackColor = True
        '
        'timerlabel13
        '
        Me.timerlabel13.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel13.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel13.Location = New System.Drawing.Point(69, 9)
        Me.timerlabel13.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel13.Name = "timerlabel13"
        Me.timerlabel13.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel13.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel13.TabIndex = 0
        Me.timerlabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Rewindbutton14
        '
        Me.Rewindbutton14.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton14.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton14.Location = New System.Drawing.Point(128, 27)
        Me.Rewindbutton14.Name = "Rewindbutton14"
        Me.Rewindbutton14.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton14.TabIndex = 14
        Me.Rewindbutton14.UseVisualStyleBackColor = True
        '
        'Rewindbutton13
        '
        Me.Rewindbutton13.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton13.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton13.Location = New System.Drawing.Point(128, 8)
        Me.Rewindbutton13.Name = "Rewindbutton13"
        Me.Rewindbutton13.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton13.TabIndex = 9
        Me.Rewindbutton13.UseVisualStyleBackColor = True
        '
        'timerlabel14
        '
        Me.timerlabel14.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel14.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel14.Location = New System.Drawing.Point(69, 28)
        Me.timerlabel14.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel14.Name = "timerlabel14"
        Me.timerlabel14.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel14.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel14.TabIndex = 12
        Me.timerlabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Stopbutton13
        '
        Me.Stopbutton13.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton13.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton13.Location = New System.Drawing.Point(149, 8)
        Me.Stopbutton13.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton13.Name = "Stopbutton13"
        Me.Stopbutton13.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton13.TabIndex = 10
        Me.Stopbutton13.UseVisualStyleBackColor = True
        '
        'Startbutton14
        '
        Me.Startbutton14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton14.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton14.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton14.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton14.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton14.Location = New System.Drawing.Point(108, 27)
        Me.Startbutton14.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton14.Name = "Startbutton14"
        Me.Startbutton14.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton14.TabIndex = 13
        Me.Startbutton14.UseVisualStyleBackColor = False
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.spellnamelabel12)
        Me.GroupBox11.Controls.Add(Me.spellnamelabel11)
        Me.GroupBox11.Controls.Add(Me.Stopbutton12)
        Me.GroupBox11.Controls.Add(Me.Rewindbutton12)
        Me.GroupBox11.Controls.Add(Me.timerlabel12)
        Me.GroupBox11.Controls.Add(Me.Startbutton12)
        Me.GroupBox11.Controls.Add(Me.spellnamelabel10)
        Me.GroupBox11.Controls.Add(Me.Startbutton10)
        Me.GroupBox11.Controls.Add(Me.Stopbutton11)
        Me.GroupBox11.Controls.Add(Me.timerlabel10)
        Me.GroupBox11.Controls.Add(Me.Rewindbutton11)
        Me.GroupBox11.Controls.Add(Me.Rewindbutton10)
        Me.GroupBox11.Controls.Add(Me.timerlabel11)
        Me.GroupBox11.Controls.Add(Me.Stopbutton10)
        Me.GroupBox11.Controls.Add(Me.Startbutton11)
        Me.GroupBox11.Location = New System.Drawing.Point(6, 223)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(170, 64)
        Me.GroupBox11.TabIndex = 21
        Me.GroupBox11.TabStop = False
        '
        'spellnamelabel12
        '
        Me.spellnamelabel12.AutoSize = True
        Me.spellnamelabel12.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel12.Location = New System.Drawing.Point(1, 49)
        Me.spellnamelabel12.Name = "spellnamelabel12"
        Me.spellnamelabel12.Size = New System.Drawing.Size(39, 8)
        Me.spellnamelabel12.TabIndex = 23
        Me.spellnamelabel12.Text = "GROMP"
        '
        'spellnamelabel11
        '
        Me.spellnamelabel11.AutoSize = True
        Me.spellnamelabel11.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel11.Location = New System.Drawing.Point(1, 32)
        Me.spellnamelabel11.Name = "spellnamelabel11"
        Me.spellnamelabel11.Size = New System.Drawing.Size(43, 8)
        Me.spellnamelabel11.TabIndex = 22
        Me.spellnamelabel11.Text = "WOLVES"
        '
        'Stopbutton12
        '
        Me.Stopbutton12.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton12.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton12.Location = New System.Drawing.Point(149, 45)
        Me.Stopbutton12.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton12.Name = "Stopbutton12"
        Me.Stopbutton12.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton12.TabIndex = 20
        Me.Stopbutton12.UseVisualStyleBackColor = True
        '
        'Rewindbutton12
        '
        Me.Rewindbutton12.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton12.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton12.Location = New System.Drawing.Point(128, 45)
        Me.Rewindbutton12.Name = "Rewindbutton12"
        Me.Rewindbutton12.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton12.TabIndex = 19
        Me.Rewindbutton12.UseVisualStyleBackColor = True
        '
        'timerlabel12
        '
        Me.timerlabel12.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel12.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel12.Location = New System.Drawing.Point(69, 46)
        Me.timerlabel12.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel12.Name = "timerlabel12"
        Me.timerlabel12.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel12.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel12.TabIndex = 17
        Me.timerlabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Startbutton12
        '
        Me.Startbutton12.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton12.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton12.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton12.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton12.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton12.Location = New System.Drawing.Point(108, 45)
        Me.Startbutton12.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton12.Name = "Startbutton12"
        Me.Startbutton12.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton12.TabIndex = 18
        Me.Startbutton12.UseVisualStyleBackColor = False
        '
        'spellnamelabel10
        '
        Me.spellnamelabel10.AutoSize = True
        Me.spellnamelabel10.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel10.Location = New System.Drawing.Point(2, 12)
        Me.spellnamelabel10.Name = "spellnamelabel10"
        Me.spellnamelabel10.Size = New System.Drawing.Size(29, 8)
        Me.spellnamelabel10.TabIndex = 5
        Me.spellnamelabel10.Text = "BLUE"
        '
        'Startbutton10
        '
        Me.Startbutton10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton10.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton10.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton10.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton10.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton10.Location = New System.Drawing.Point(108, 8)
        Me.Startbutton10.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton10.Name = "Startbutton10"
        Me.Startbutton10.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton10.TabIndex = 1
        Me.Startbutton10.UseVisualStyleBackColor = False
        '
        'Stopbutton11
        '
        Me.Stopbutton11.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton11.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton11.Location = New System.Drawing.Point(149, 27)
        Me.Stopbutton11.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton11.Name = "Stopbutton11"
        Me.Stopbutton11.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton11.TabIndex = 15
        Me.Stopbutton11.UseVisualStyleBackColor = True
        '
        'timerlabel10
        '
        Me.timerlabel10.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel10.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel10.Location = New System.Drawing.Point(69, 9)
        Me.timerlabel10.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel10.Name = "timerlabel10"
        Me.timerlabel10.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel10.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel10.TabIndex = 0
        Me.timerlabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Rewindbutton11
        '
        Me.Rewindbutton11.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton11.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton11.Location = New System.Drawing.Point(128, 27)
        Me.Rewindbutton11.Name = "Rewindbutton11"
        Me.Rewindbutton11.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton11.TabIndex = 14
        Me.Rewindbutton11.UseVisualStyleBackColor = True
        '
        'Rewindbutton10
        '
        Me.Rewindbutton10.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton10.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton10.Location = New System.Drawing.Point(128, 8)
        Me.Rewindbutton10.Name = "Rewindbutton10"
        Me.Rewindbutton10.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton10.TabIndex = 9
        Me.Rewindbutton10.UseVisualStyleBackColor = True
        '
        'timerlabel11
        '
        Me.timerlabel11.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel11.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel11.Location = New System.Drawing.Point(69, 28)
        Me.timerlabel11.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel11.Name = "timerlabel11"
        Me.timerlabel11.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel11.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel11.TabIndex = 12
        Me.timerlabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Stopbutton10
        '
        Me.Stopbutton10.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton10.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton10.Location = New System.Drawing.Point(149, 8)
        Me.Stopbutton10.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton10.Name = "Stopbutton10"
        Me.Stopbutton10.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton10.TabIndex = 10
        Me.Stopbutton10.UseVisualStyleBackColor = True
        '
        'Startbutton11
        '
        Me.Startbutton11.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton11.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton11.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton11.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton11.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton11.Location = New System.Drawing.Point(108, 27)
        Me.Startbutton11.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton11.Name = "Startbutton11"
        Me.Startbutton11.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton11.TabIndex = 13
        Me.Startbutton11.UseVisualStyleBackColor = False
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Role5)
        Me.GroupBox10.Controls.Add(Me.spellnamelabel9)
        Me.GroupBox10.Controls.Add(Me.Startbutton8)
        Me.GroupBox10.Controls.Add(Me.Stopbutton9)
        Me.GroupBox10.Controls.Add(Me.timerlabel8)
        Me.GroupBox10.Controls.Add(Me.Rewindbutton9)
        Me.GroupBox10.Controls.Add(Me.Rewindbutton8)
        Me.GroupBox10.Controls.Add(Me.timerlabel9)
        Me.GroupBox10.Controls.Add(Me.Stopbutton8)
        Me.GroupBox10.Controls.Add(Me.Startbutton9)
        Me.GroupBox10.Controls.Add(Me.spellnamelabel8)
        Me.GroupBox10.Location = New System.Drawing.Point(6, 174)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(170, 46)
        Me.GroupBox10.TabIndex = 20
        Me.GroupBox10.TabStop = False
        '
        'Role5
        '
        Me.Role5.AutoSize = True
        Me.Role5.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Role5.Location = New System.Drawing.Point(2, 12)
        Me.Role5.Name = "Role5"
        Me.Role5.Size = New System.Drawing.Size(24, 8)
        Me.Role5.TabIndex = 5
        Me.Role5.Text = "SUP"
        '
        'spellnamelabel9
        '
        Me.spellnamelabel9.BackColor = System.Drawing.Color.White
        Me.spellnamelabel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.spellnamelabel9.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel9.Location = New System.Drawing.Point(26, 28)
        Me.spellnamelabel9.Name = "spellnamelabel9"
        Me.spellnamelabel9.Size = New System.Drawing.Size(37, 15)
        Me.spellnamelabel9.TabIndex = 16
        Me.spellnamelabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Startbutton8
        '
        Me.Startbutton8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton8.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton8.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton8.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton8.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton8.Location = New System.Drawing.Point(108, 8)
        Me.Startbutton8.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton8.Name = "Startbutton8"
        Me.Startbutton8.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton8.TabIndex = 1
        Me.Startbutton8.UseVisualStyleBackColor = False
        '
        'Stopbutton9
        '
        Me.Stopbutton9.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton9.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton9.Location = New System.Drawing.Point(149, 27)
        Me.Stopbutton9.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton9.Name = "Stopbutton9"
        Me.Stopbutton9.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton9.TabIndex = 15
        Me.Stopbutton9.UseVisualStyleBackColor = True
        '
        'timerlabel8
        '
        Me.timerlabel8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel8.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel8.Location = New System.Drawing.Point(69, 9)
        Me.timerlabel8.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel8.Name = "timerlabel8"
        Me.timerlabel8.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel8.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel8.TabIndex = 0
        Me.timerlabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Rewindbutton9
        '
        Me.Rewindbutton9.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton9.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton9.Location = New System.Drawing.Point(128, 27)
        Me.Rewindbutton9.Name = "Rewindbutton9"
        Me.Rewindbutton9.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton9.TabIndex = 14
        Me.Rewindbutton9.UseVisualStyleBackColor = True
        '
        'Rewindbutton8
        '
        Me.Rewindbutton8.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton8.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton8.Location = New System.Drawing.Point(128, 8)
        Me.Rewindbutton8.Name = "Rewindbutton8"
        Me.Rewindbutton8.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton8.TabIndex = 9
        Me.Rewindbutton8.UseVisualStyleBackColor = True
        '
        'timerlabel9
        '
        Me.timerlabel9.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel9.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel9.Location = New System.Drawing.Point(69, 28)
        Me.timerlabel9.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel9.Name = "timerlabel9"
        Me.timerlabel9.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel9.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel9.TabIndex = 12
        Me.timerlabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Stopbutton8
        '
        Me.Stopbutton8.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton8.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton8.Location = New System.Drawing.Point(149, 8)
        Me.Stopbutton8.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton8.Name = "Stopbutton8"
        Me.Stopbutton8.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton8.TabIndex = 10
        Me.Stopbutton8.UseVisualStyleBackColor = True
        '
        'Startbutton9
        '
        Me.Startbutton9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton9.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton9.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton9.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton9.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton9.Location = New System.Drawing.Point(108, 27)
        Me.Startbutton9.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton9.Name = "Startbutton9"
        Me.Startbutton9.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton9.TabIndex = 13
        Me.Startbutton9.UseVisualStyleBackColor = False
        '
        'spellnamelabel8
        '
        Me.spellnamelabel8.BackColor = System.Drawing.Color.White
        Me.spellnamelabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.spellnamelabel8.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel8.Location = New System.Drawing.Point(26, 9)
        Me.spellnamelabel8.Name = "spellnamelabel8"
        Me.spellnamelabel8.Size = New System.Drawing.Size(37, 15)
        Me.spellnamelabel8.TabIndex = 11
        Me.spellnamelabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Role4)
        Me.GroupBox9.Controls.Add(Me.spellnamelabel7)
        Me.GroupBox9.Controls.Add(Me.Startbutton6)
        Me.GroupBox9.Controls.Add(Me.Stopbutton7)
        Me.GroupBox9.Controls.Add(Me.timerlabel6)
        Me.GroupBox9.Controls.Add(Me.Rewindbutton7)
        Me.GroupBox9.Controls.Add(Me.Rewindbutton6)
        Me.GroupBox9.Controls.Add(Me.timerlabel7)
        Me.GroupBox9.Controls.Add(Me.Stopbutton6)
        Me.GroupBox9.Controls.Add(Me.Startbutton7)
        Me.GroupBox9.Controls.Add(Me.spellnamelabel6)
        Me.GroupBox9.Location = New System.Drawing.Point(6, 127)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(170, 46)
        Me.GroupBox9.TabIndex = 19
        Me.GroupBox9.TabStop = False
        '
        'Role4
        '
        Me.Role4.AutoSize = True
        Me.Role4.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Role4.Location = New System.Drawing.Point(1, 12)
        Me.Role4.Name = "Role4"
        Me.Role4.Size = New System.Drawing.Size(25, 8)
        Me.Role4.TabIndex = 5
        Me.Role4.Text = "ADC"
        '
        'spellnamelabel7
        '
        Me.spellnamelabel7.BackColor = System.Drawing.Color.White
        Me.spellnamelabel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.spellnamelabel7.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel7.Location = New System.Drawing.Point(26, 28)
        Me.spellnamelabel7.Name = "spellnamelabel7"
        Me.spellnamelabel7.Size = New System.Drawing.Size(37, 15)
        Me.spellnamelabel7.TabIndex = 16
        Me.spellnamelabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Startbutton6
        '
        Me.Startbutton6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton6.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton6.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton6.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton6.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton6.Location = New System.Drawing.Point(108, 8)
        Me.Startbutton6.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton6.Name = "Startbutton6"
        Me.Startbutton6.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton6.TabIndex = 1
        Me.Startbutton6.UseVisualStyleBackColor = False
        '
        'Stopbutton7
        '
        Me.Stopbutton7.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton7.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton7.Location = New System.Drawing.Point(149, 27)
        Me.Stopbutton7.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton7.Name = "Stopbutton7"
        Me.Stopbutton7.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton7.TabIndex = 15
        Me.Stopbutton7.UseVisualStyleBackColor = True
        '
        'timerlabel6
        '
        Me.timerlabel6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel6.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel6.Location = New System.Drawing.Point(69, 9)
        Me.timerlabel6.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel6.Name = "timerlabel6"
        Me.timerlabel6.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel6.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel6.TabIndex = 0
        Me.timerlabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Rewindbutton7
        '
        Me.Rewindbutton7.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton7.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton7.Location = New System.Drawing.Point(128, 27)
        Me.Rewindbutton7.Name = "Rewindbutton7"
        Me.Rewindbutton7.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton7.TabIndex = 14
        Me.Rewindbutton7.UseVisualStyleBackColor = True
        '
        'Rewindbutton6
        '
        Me.Rewindbutton6.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton6.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton6.Location = New System.Drawing.Point(128, 8)
        Me.Rewindbutton6.Name = "Rewindbutton6"
        Me.Rewindbutton6.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton6.TabIndex = 9
        Me.Rewindbutton6.UseVisualStyleBackColor = True
        '
        'timerlabel7
        '
        Me.timerlabel7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel7.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel7.Location = New System.Drawing.Point(69, 28)
        Me.timerlabel7.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel7.Name = "timerlabel7"
        Me.timerlabel7.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel7.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel7.TabIndex = 12
        Me.timerlabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Stopbutton6
        '
        Me.Stopbutton6.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton6.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton6.Location = New System.Drawing.Point(149, 8)
        Me.Stopbutton6.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton6.Name = "Stopbutton6"
        Me.Stopbutton6.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton6.TabIndex = 10
        Me.Stopbutton6.UseVisualStyleBackColor = True
        '
        'Startbutton7
        '
        Me.Startbutton7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton7.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton7.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton7.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton7.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton7.Location = New System.Drawing.Point(108, 27)
        Me.Startbutton7.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton7.Name = "Startbutton7"
        Me.Startbutton7.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton7.TabIndex = 13
        Me.Startbutton7.UseVisualStyleBackColor = False
        '
        'spellnamelabel6
        '
        Me.spellnamelabel6.BackColor = System.Drawing.Color.White
        Me.spellnamelabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.spellnamelabel6.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel6.Location = New System.Drawing.Point(26, 9)
        Me.spellnamelabel6.Name = "spellnamelabel6"
        Me.spellnamelabel6.Size = New System.Drawing.Size(37, 15)
        Me.spellnamelabel6.TabIndex = 11
        Me.spellnamelabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Role3)
        Me.GroupBox8.Controls.Add(Me.spellnamelabel5)
        Me.GroupBox8.Controls.Add(Me.Startbutton4)
        Me.GroupBox8.Controls.Add(Me.Stopbutton5)
        Me.GroupBox8.Controls.Add(Me.timerlabel4)
        Me.GroupBox8.Controls.Add(Me.Rewindbutton5)
        Me.GroupBox8.Controls.Add(Me.Rewindbutton4)
        Me.GroupBox8.Controls.Add(Me.timerlabel5)
        Me.GroupBox8.Controls.Add(Me.Stopbutton4)
        Me.GroupBox8.Controls.Add(Me.Startbutton5)
        Me.GroupBox8.Controls.Add(Me.spellnamelabel4)
        Me.GroupBox8.Location = New System.Drawing.Point(6, 80)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(170, 46)
        Me.GroupBox8.TabIndex = 18
        Me.GroupBox8.TabStop = False
        '
        'Role3
        '
        Me.Role3.AutoSize = True
        Me.Role3.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Role3.Location = New System.Drawing.Point(2, 12)
        Me.Role3.Name = "Role3"
        Me.Role3.Size = New System.Drawing.Size(23, 8)
        Me.Role3.TabIndex = 5
        Me.Role3.Text = "MID"
        '
        'spellnamelabel5
        '
        Me.spellnamelabel5.BackColor = System.Drawing.Color.White
        Me.spellnamelabel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.spellnamelabel5.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel5.Location = New System.Drawing.Point(26, 28)
        Me.spellnamelabel5.Name = "spellnamelabel5"
        Me.spellnamelabel5.Size = New System.Drawing.Size(37, 15)
        Me.spellnamelabel5.TabIndex = 16
        Me.spellnamelabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Startbutton4
        '
        Me.Startbutton4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton4.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton4.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton4.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton4.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton4.Location = New System.Drawing.Point(108, 8)
        Me.Startbutton4.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton4.Name = "Startbutton4"
        Me.Startbutton4.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton4.TabIndex = 1
        Me.Startbutton4.UseVisualStyleBackColor = False
        '
        'Stopbutton5
        '
        Me.Stopbutton5.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton5.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton5.Location = New System.Drawing.Point(149, 27)
        Me.Stopbutton5.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton5.Name = "Stopbutton5"
        Me.Stopbutton5.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton5.TabIndex = 15
        Me.Stopbutton5.UseVisualStyleBackColor = True
        '
        'timerlabel4
        '
        Me.timerlabel4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel4.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel4.Location = New System.Drawing.Point(69, 9)
        Me.timerlabel4.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel4.Name = "timerlabel4"
        Me.timerlabel4.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel4.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel4.TabIndex = 0
        Me.timerlabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Rewindbutton5
        '
        Me.Rewindbutton5.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton5.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton5.Location = New System.Drawing.Point(128, 27)
        Me.Rewindbutton5.Name = "Rewindbutton5"
        Me.Rewindbutton5.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton5.TabIndex = 14
        Me.Rewindbutton5.UseVisualStyleBackColor = True
        '
        'Rewindbutton4
        '
        Me.Rewindbutton4.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton4.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton4.Location = New System.Drawing.Point(128, 8)
        Me.Rewindbutton4.Name = "Rewindbutton4"
        Me.Rewindbutton4.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton4.TabIndex = 9
        Me.Rewindbutton4.UseVisualStyleBackColor = True
        '
        'timerlabel5
        '
        Me.timerlabel5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel5.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel5.Location = New System.Drawing.Point(69, 28)
        Me.timerlabel5.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel5.Name = "timerlabel5"
        Me.timerlabel5.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel5.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel5.TabIndex = 12
        Me.timerlabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Stopbutton4
        '
        Me.Stopbutton4.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton4.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton4.Location = New System.Drawing.Point(149, 8)
        Me.Stopbutton4.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton4.Name = "Stopbutton4"
        Me.Stopbutton4.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton4.TabIndex = 10
        Me.Stopbutton4.UseVisualStyleBackColor = True
        '
        'Startbutton5
        '
        Me.Startbutton5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton5.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton5.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton5.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton5.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton5.Location = New System.Drawing.Point(108, 27)
        Me.Startbutton5.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton5.Name = "Startbutton5"
        Me.Startbutton5.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton5.TabIndex = 13
        Me.Startbutton5.UseVisualStyleBackColor = False
        '
        'spellnamelabel4
        '
        Me.spellnamelabel4.BackColor = System.Drawing.Color.White
        Me.spellnamelabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.spellnamelabel4.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel4.Location = New System.Drawing.Point(26, 9)
        Me.spellnamelabel4.Name = "spellnamelabel4"
        Me.spellnamelabel4.Size = New System.Drawing.Size(37, 15)
        Me.spellnamelabel4.TabIndex = 11
        Me.spellnamelabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Role2)
        Me.GroupBox7.Controls.Add(Me.Startbutton3)
        Me.GroupBox7.Controls.Add(Me.timerlabel3)
        Me.GroupBox7.Controls.Add(Me.Rewindbutton3)
        Me.GroupBox7.Controls.Add(Me.Stopbutton3)
        Me.GroupBox7.Controls.Add(Me.spellnamelabel3)
        Me.GroupBox7.Location = New System.Drawing.Point(6, 52)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(170, 28)
        Me.GroupBox7.TabIndex = 18
        Me.GroupBox7.TabStop = False
        '
        'Role2
        '
        Me.Role2.AutoSize = True
        Me.Role2.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Role2.Location = New System.Drawing.Point(2, 12)
        Me.Role2.Name = "Role2"
        Me.Role2.Size = New System.Drawing.Size(21, 8)
        Me.Role2.TabIndex = 5
        Me.Role2.Text = " JG"
        '
        'Startbutton3
        '
        Me.Startbutton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton3.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton3.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton3.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton3.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton3.Location = New System.Drawing.Point(108, 8)
        Me.Startbutton3.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton3.Name = "Startbutton3"
        Me.Startbutton3.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton3.TabIndex = 1
        Me.Startbutton3.UseVisualStyleBackColor = False
        '
        'timerlabel3
        '
        Me.timerlabel3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel3.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel3.Location = New System.Drawing.Point(69, 9)
        Me.timerlabel3.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel3.Name = "timerlabel3"
        Me.timerlabel3.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel3.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel3.TabIndex = 0
        Me.timerlabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Rewindbutton3
        '
        Me.Rewindbutton3.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton3.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton3.Location = New System.Drawing.Point(128, 8)
        Me.Rewindbutton3.Name = "Rewindbutton3"
        Me.Rewindbutton3.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton3.TabIndex = 9
        Me.Rewindbutton3.UseVisualStyleBackColor = True
        '
        'Stopbutton3
        '
        Me.Stopbutton3.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton3.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton3.Location = New System.Drawing.Point(149, 8)
        Me.Stopbutton3.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton3.Name = "Stopbutton3"
        Me.Stopbutton3.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton3.TabIndex = 10
        Me.Stopbutton3.UseVisualStyleBackColor = True
        '
        'spellnamelabel3
        '
        Me.spellnamelabel3.BackColor = System.Drawing.Color.White
        Me.spellnamelabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.spellnamelabel3.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel3.Location = New System.Drawing.Point(26, 9)
        Me.spellnamelabel3.Name = "spellnamelabel3"
        Me.spellnamelabel3.Size = New System.Drawing.Size(37, 15)
        Me.spellnamelabel3.TabIndex = 11
        Me.spellnamelabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.role1)
        Me.GroupBox6.Controls.Add(Me.spellnamelabel2)
        Me.GroupBox6.Controls.Add(Me.Startbutton1)
        Me.GroupBox6.Controls.Add(Me.Stopbutton2)
        Me.GroupBox6.Controls.Add(Me.timerlabel1)
        Me.GroupBox6.Controls.Add(Me.Rewindbutton2)
        Me.GroupBox6.Controls.Add(Me.Rewindbutton1)
        Me.GroupBox6.Controls.Add(Me.timerlabel2)
        Me.GroupBox6.Controls.Add(Me.Stopbutton1)
        Me.GroupBox6.Controls.Add(Me.Startbutton2)
        Me.GroupBox6.Controls.Add(Me.spellnamelabel1)
        Me.GroupBox6.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(170, 46)
        Me.GroupBox6.TabIndex = 17
        Me.GroupBox6.TabStop = False
        '
        'spellnamelabel2
        '
        Me.spellnamelabel2.BackColor = System.Drawing.Color.White
        Me.spellnamelabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.spellnamelabel2.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel2.Location = New System.Drawing.Point(26, 28)
        Me.spellnamelabel2.Name = "spellnamelabel2"
        Me.spellnamelabel2.Size = New System.Drawing.Size(37, 15)
        Me.spellnamelabel2.TabIndex = 16
        Me.spellnamelabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Startbutton1
        '
        Me.Startbutton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton1.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton1.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton1.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton1.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton1.Location = New System.Drawing.Point(108, 8)
        Me.Startbutton1.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton1.Name = "Startbutton1"
        Me.Startbutton1.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton1.TabIndex = 1
        Me.Startbutton1.UseVisualStyleBackColor = False
        '
        'Stopbutton2
        '
        Me.Stopbutton2.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton2.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton2.Location = New System.Drawing.Point(149, 27)
        Me.Stopbutton2.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton2.Name = "Stopbutton2"
        Me.Stopbutton2.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton2.TabIndex = 15
        Me.Stopbutton2.UseVisualStyleBackColor = True
        '
        'Rewindbutton2
        '
        Me.Rewindbutton2.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton2.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton2.Location = New System.Drawing.Point(128, 27)
        Me.Rewindbutton2.Name = "Rewindbutton2"
        Me.Rewindbutton2.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton2.TabIndex = 14
        Me.Rewindbutton2.UseVisualStyleBackColor = True
        '
        'Rewindbutton1
        '
        Me.Rewindbutton1.Font = New System.Drawing.Font("Batang", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Rewindbutton1.Image = Global.Spell_Timer.My.Resources.Resources.rewind
        Me.Rewindbutton1.Location = New System.Drawing.Point(128, 8)
        Me.Rewindbutton1.Name = "Rewindbutton1"
        Me.Rewindbutton1.Size = New System.Drawing.Size(19, 16)
        Me.Rewindbutton1.TabIndex = 9
        Me.Rewindbutton1.UseVisualStyleBackColor = True
        '
        'timerlabel2
        '
        Me.timerlabel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.timerlabel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.timerlabel2.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.timerlabel2.Location = New System.Drawing.Point(69, 28)
        Me.timerlabel2.Margin = New System.Windows.Forms.Padding(3)
        Me.timerlabel2.Name = "timerlabel2"
        Me.timerlabel2.Padding = New System.Windows.Forms.Padding(1)
        Me.timerlabel2.Size = New System.Drawing.Size(37, 16)
        Me.timerlabel2.TabIndex = 12
        Me.timerlabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Stopbutton1
        '
        Me.Stopbutton1.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Stopbutton1.Image = Global.Spell_Timer.My.Resources.Resources._stop
        Me.Stopbutton1.Location = New System.Drawing.Point(149, 8)
        Me.Stopbutton1.Margin = New System.Windows.Forms.Padding(1)
        Me.Stopbutton1.Name = "Stopbutton1"
        Me.Stopbutton1.Size = New System.Drawing.Size(19, 16)
        Me.Stopbutton1.TabIndex = 10
        Me.Stopbutton1.UseVisualStyleBackColor = True
        '
        'Startbutton2
        '
        Me.Startbutton2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Startbutton2.BackColor = System.Drawing.Color.Transparent
        Me.Startbutton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Startbutton2.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Startbutton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.Startbutton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.Startbutton2.Font = New System.Drawing.Font("Gulim", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Startbutton2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Startbutton2.Image = Global.Spell_Timer.My.Resources.Resources.play3
        Me.Startbutton2.Location = New System.Drawing.Point(108, 27)
        Me.Startbutton2.Margin = New System.Windows.Forms.Padding(0)
        Me.Startbutton2.Name = "Startbutton2"
        Me.Startbutton2.Size = New System.Drawing.Size(18, 16)
        Me.Startbutton2.TabIndex = 13
        Me.Startbutton2.UseVisualStyleBackColor = False
        '
        'spellnamelabel1
        '
        Me.spellnamelabel1.BackColor = System.Drawing.Color.White
        Me.spellnamelabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.spellnamelabel1.Font = New System.Drawing.Font("Gulim", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.spellnamelabel1.Location = New System.Drawing.Point(26, 9)
        Me.spellnamelabel1.Name = "spellnamelabel1"
        Me.spellnamelabel1.Size = New System.Drawing.Size(37, 15)
        Me.spellnamelabel1.TabIndex = 11
        Me.spellnamelabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage2.Controls.Add(Me.GroupBox5)
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Controls.Add(Me.GroupBox1)
        Me.TabPage2.Controls.Add(Me.setting2)
        Me.TabPage2.Controls.Add(Me.setting1)
        Me.TabPage2.Font = New System.Drawing.Font("Gulim", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(193, 404)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "SETTINGS"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Ioniancheckbox2)
        Me.GroupBox5.Controls.Add(Me.Insightcheckbox2)
        Me.GroupBox5.Controls.Add(Me.Spellcombobox1)
        Me.GroupBox5.Controls.Add(Me.Insightcheckbox1)
        Me.GroupBox5.Controls.Add(Me.Ioniancheckbox1)
        Me.GroupBox5.Controls.Add(Me.Spellcombobox2)
        Me.GroupBox5.Location = New System.Drawing.Point(6, 36)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(181, 49)
        Me.GroupBox5.TabIndex = 37
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "TOP"
        '
        'Ioniancheckbox2
        '
        Me.Ioniancheckbox2.AutoSize = True
        Me.Ioniancheckbox2.Location = New System.Drawing.Point(153, 29)
        Me.Ioniancheckbox2.Name = "Ioniancheckbox2"
        Me.Ioniancheckbox2.Size = New System.Drawing.Size(15, 14)
        Me.Ioniancheckbox2.TabIndex = 39
        Me.Ioniancheckbox2.UseVisualStyleBackColor = True
        Me.Ioniancheckbox2.Visible = False
        '
        'Insightcheckbox2
        '
        Me.Insightcheckbox2.AutoSize = True
        Me.Insightcheckbox2.Location = New System.Drawing.Point(118, 29)
        Me.Insightcheckbox2.Name = "Insightcheckbox2"
        Me.Insightcheckbox2.Size = New System.Drawing.Size(15, 14)
        Me.Insightcheckbox2.TabIndex = 39
        Me.Insightcheckbox2.UseVisualStyleBackColor = True
        Me.Insightcheckbox2.Visible = False
        '
        'Spellcombobox1
        '
        Me.Spellcombobox1.FormattingEnabled = True
        Me.Spellcombobox1.Items.AddRange(New Object() {"Flash", "Ghost", "Teleport", "Ignite", "Exhaust", "Heal", "Barrier", "Cleanse"})
        Me.Spellcombobox1.Location = New System.Drawing.Point(39, 0)
        Me.Spellcombobox1.Name = "Spellcombobox1"
        Me.Spellcombobox1.Size = New System.Drawing.Size(66, 20)
        Me.Spellcombobox1.TabIndex = 7
        '
        'Insightcheckbox1
        '
        Me.Insightcheckbox1.AutoSize = True
        Me.Insightcheckbox1.Location = New System.Drawing.Point(118, 3)
        Me.Insightcheckbox1.Name = "Insightcheckbox1"
        Me.Insightcheckbox1.Size = New System.Drawing.Size(15, 14)
        Me.Insightcheckbox1.TabIndex = 10
        Me.Insightcheckbox1.UseVisualStyleBackColor = True
        '
        'Ioniancheckbox1
        '
        Me.Ioniancheckbox1.AutoSize = True
        Me.Ioniancheckbox1.Location = New System.Drawing.Point(153, 3)
        Me.Ioniancheckbox1.Name = "Ioniancheckbox1"
        Me.Ioniancheckbox1.Size = New System.Drawing.Size(15, 14)
        Me.Ioniancheckbox1.TabIndex = 11
        Me.Ioniancheckbox1.UseVisualStyleBackColor = True
        '
        'Spellcombobox2
        '
        Me.Spellcombobox2.FormattingEnabled = True
        Me.Spellcombobox2.Items.AddRange(New Object() {"Flash", "Ghost", "Teleport", "Ignite", "Exhaust", "Heal", "Barrier", "Cleanse"})
        Me.Spellcombobox2.Location = New System.Drawing.Point(39, 26)
        Me.Spellcombobox2.Name = "Spellcombobox2"
        Me.Spellcombobox2.Size = New System.Drawing.Size(66, 20)
        Me.Spellcombobox2.TabIndex = 12
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Spellcombobox3)
        Me.GroupBox4.Controls.Add(Me.Insightcheckbox3)
        Me.GroupBox4.Controls.Add(Me.Ioniancheckbox3)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 91)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(181, 26)
        Me.GroupBox4.TabIndex = 38
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "  JG"
        '
        'Spellcombobox3
        '
        Me.Spellcombobox3.FormattingEnabled = True
        Me.Spellcombobox3.Items.AddRange(New Object() {"Flash", "Ghost", "Teleport", "Ignite", "Exhaust", "Heal", "Barrier", "Cleanse"})
        Me.Spellcombobox3.Location = New System.Drawing.Point(39, 0)
        Me.Spellcombobox3.Name = "Spellcombobox3"
        Me.Spellcombobox3.Size = New System.Drawing.Size(66, 20)
        Me.Spellcombobox3.TabIndex = 30
        '
        'Insightcheckbox3
        '
        Me.Insightcheckbox3.AutoSize = True
        Me.Insightcheckbox3.Location = New System.Drawing.Point(118, 3)
        Me.Insightcheckbox3.Name = "Insightcheckbox3"
        Me.Insightcheckbox3.Size = New System.Drawing.Size(15, 14)
        Me.Insightcheckbox3.TabIndex = 31
        Me.Insightcheckbox3.UseVisualStyleBackColor = True
        '
        'Ioniancheckbox3
        '
        Me.Ioniancheckbox3.AutoSize = True
        Me.Ioniancheckbox3.Location = New System.Drawing.Point(153, 3)
        Me.Ioniancheckbox3.Name = "Ioniancheckbox3"
        Me.Ioniancheckbox3.Size = New System.Drawing.Size(15, 14)
        Me.Ioniancheckbox3.TabIndex = 32
        Me.Ioniancheckbox3.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Insightcheckbox5)
        Me.GroupBox3.Controls.Add(Me.Ioniancheckbox5)
        Me.GroupBox3.Controls.Add(Me.Spellcombobox4)
        Me.GroupBox3.Controls.Add(Me.Insightcheckbox4)
        Me.GroupBox3.Controls.Add(Me.Ioniancheckbox4)
        Me.GroupBox3.Controls.Add(Me.Spellcombobox5)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 120)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(181, 49)
        Me.GroupBox3.TabIndex = 37
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "MID"
        '
        'Insightcheckbox5
        '
        Me.Insightcheckbox5.AutoSize = True
        Me.Insightcheckbox5.Location = New System.Drawing.Point(118, 29)
        Me.Insightcheckbox5.Name = "Insightcheckbox5"
        Me.Insightcheckbox5.Size = New System.Drawing.Size(15, 14)
        Me.Insightcheckbox5.TabIndex = 39
        Me.Insightcheckbox5.UseVisualStyleBackColor = True
        Me.Insightcheckbox5.Visible = False
        '
        'Ioniancheckbox5
        '
        Me.Ioniancheckbox5.AutoSize = True
        Me.Ioniancheckbox5.Location = New System.Drawing.Point(153, 29)
        Me.Ioniancheckbox5.Name = "Ioniancheckbox5"
        Me.Ioniancheckbox5.Size = New System.Drawing.Size(15, 14)
        Me.Ioniancheckbox5.TabIndex = 40
        Me.Ioniancheckbox5.UseVisualStyleBackColor = True
        Me.Ioniancheckbox5.Visible = False
        '
        'Spellcombobox4
        '
        Me.Spellcombobox4.FormattingEnabled = True
        Me.Spellcombobox4.Items.AddRange(New Object() {"Flash", "Ghost", "Teleport", "Ignite", "Exhaust", "Heal", "Barrier", "Cleanse"})
        Me.Spellcombobox4.Location = New System.Drawing.Point(39, 0)
        Me.Spellcombobox4.Name = "Spellcombobox4"
        Me.Spellcombobox4.Size = New System.Drawing.Size(66, 20)
        Me.Spellcombobox4.TabIndex = 30
        '
        'Insightcheckbox4
        '
        Me.Insightcheckbox4.AutoSize = True
        Me.Insightcheckbox4.Location = New System.Drawing.Point(118, 3)
        Me.Insightcheckbox4.Name = "Insightcheckbox4"
        Me.Insightcheckbox4.Size = New System.Drawing.Size(15, 14)
        Me.Insightcheckbox4.TabIndex = 31
        Me.Insightcheckbox4.UseVisualStyleBackColor = True
        '
        'Ioniancheckbox4
        '
        Me.Ioniancheckbox4.AutoSize = True
        Me.Ioniancheckbox4.Location = New System.Drawing.Point(153, 3)
        Me.Ioniancheckbox4.Name = "Ioniancheckbox4"
        Me.Ioniancheckbox4.Size = New System.Drawing.Size(15, 14)
        Me.Ioniancheckbox4.TabIndex = 32
        Me.Ioniancheckbox4.UseVisualStyleBackColor = True
        '
        'Spellcombobox5
        '
        Me.Spellcombobox5.FormattingEnabled = True
        Me.Spellcombobox5.Items.AddRange(New Object() {"Flash", "Ghost", "Teleport", "Ignite", "Exhaust", "Heal", "Barrier", "Cleanse"})
        Me.Spellcombobox5.Location = New System.Drawing.Point(39, 26)
        Me.Spellcombobox5.Name = "Spellcombobox5"
        Me.Spellcombobox5.Size = New System.Drawing.Size(66, 20)
        Me.Spellcombobox5.TabIndex = 33
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Insightcheckbox7)
        Me.GroupBox2.Controls.Add(Me.Ioniancheckbox7)
        Me.GroupBox2.Controls.Add(Me.Spellcombobox6)
        Me.GroupBox2.Controls.Add(Me.Insightcheckbox6)
        Me.GroupBox2.Controls.Add(Me.Ioniancheckbox6)
        Me.GroupBox2.Controls.Add(Me.Spellcombobox7)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 175)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(181, 49)
        Me.GroupBox2.TabIndex = 37
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "ADC"
        '
        'Insightcheckbox7
        '
        Me.Insightcheckbox7.AutoSize = True
        Me.Insightcheckbox7.Location = New System.Drawing.Point(118, 29)
        Me.Insightcheckbox7.Name = "Insightcheckbox7"
        Me.Insightcheckbox7.Size = New System.Drawing.Size(15, 14)
        Me.Insightcheckbox7.TabIndex = 39
        Me.Insightcheckbox7.UseVisualStyleBackColor = True
        Me.Insightcheckbox7.Visible = False
        '
        'Ioniancheckbox7
        '
        Me.Ioniancheckbox7.AutoSize = True
        Me.Ioniancheckbox7.Location = New System.Drawing.Point(153, 29)
        Me.Ioniancheckbox7.Name = "Ioniancheckbox7"
        Me.Ioniancheckbox7.Size = New System.Drawing.Size(15, 14)
        Me.Ioniancheckbox7.TabIndex = 40
        Me.Ioniancheckbox7.UseVisualStyleBackColor = True
        Me.Ioniancheckbox7.Visible = False
        '
        'Spellcombobox6
        '
        Me.Spellcombobox6.FormattingEnabled = True
        Me.Spellcombobox6.Items.AddRange(New Object() {"Flash", "Ghost", "Teleport", "Ignite", "Exhaust", "Heal", "Barrier", "Cleanse"})
        Me.Spellcombobox6.Location = New System.Drawing.Point(39, 0)
        Me.Spellcombobox6.Name = "Spellcombobox6"
        Me.Spellcombobox6.Size = New System.Drawing.Size(66, 20)
        Me.Spellcombobox6.TabIndex = 30
        '
        'Insightcheckbox6
        '
        Me.Insightcheckbox6.AutoSize = True
        Me.Insightcheckbox6.Location = New System.Drawing.Point(118, 3)
        Me.Insightcheckbox6.Name = "Insightcheckbox6"
        Me.Insightcheckbox6.Size = New System.Drawing.Size(15, 14)
        Me.Insightcheckbox6.TabIndex = 31
        Me.Insightcheckbox6.UseVisualStyleBackColor = True
        '
        'Ioniancheckbox6
        '
        Me.Ioniancheckbox6.AutoSize = True
        Me.Ioniancheckbox6.Location = New System.Drawing.Point(153, 3)
        Me.Ioniancheckbox6.Name = "Ioniancheckbox6"
        Me.Ioniancheckbox6.Size = New System.Drawing.Size(15, 14)
        Me.Ioniancheckbox6.TabIndex = 32
        Me.Ioniancheckbox6.UseVisualStyleBackColor = True
        '
        'Spellcombobox7
        '
        Me.Spellcombobox7.FormattingEnabled = True
        Me.Spellcombobox7.Items.AddRange(New Object() {"Flash", "Ghost", "Teleport", "Ignite", "Exhaust", "Heal", "Barrier", "Cleanse"})
        Me.Spellcombobox7.Location = New System.Drawing.Point(39, 26)
        Me.Spellcombobox7.Name = "Spellcombobox7"
        Me.Spellcombobox7.Size = New System.Drawing.Size(66, 20)
        Me.Spellcombobox7.TabIndex = 33
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Insightcheckbox9)
        Me.GroupBox1.Controls.Add(Me.Ioniancheckbox9)
        Me.GroupBox1.Controls.Add(Me.Spellcombobox8)
        Me.GroupBox1.Controls.Add(Me.Insightcheckbox8)
        Me.GroupBox1.Controls.Add(Me.Ioniancheckbox8)
        Me.GroupBox1.Controls.Add(Me.Spellcombobox9)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 230)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(181, 49)
        Me.GroupBox1.TabIndex = 36
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "SUP"
        '
        'Insightcheckbox9
        '
        Me.Insightcheckbox9.AutoSize = True
        Me.Insightcheckbox9.Location = New System.Drawing.Point(118, 29)
        Me.Insightcheckbox9.Name = "Insightcheckbox9"
        Me.Insightcheckbox9.Size = New System.Drawing.Size(15, 14)
        Me.Insightcheckbox9.TabIndex = 39
        Me.Insightcheckbox9.UseVisualStyleBackColor = True
        Me.Insightcheckbox9.Visible = False
        '
        'Ioniancheckbox9
        '
        Me.Ioniancheckbox9.AutoSize = True
        Me.Ioniancheckbox9.Location = New System.Drawing.Point(153, 29)
        Me.Ioniancheckbox9.Name = "Ioniancheckbox9"
        Me.Ioniancheckbox9.Size = New System.Drawing.Size(15, 14)
        Me.Ioniancheckbox9.TabIndex = 40
        Me.Ioniancheckbox9.UseVisualStyleBackColor = True
        Me.Ioniancheckbox9.Visible = False
        '
        'Spellcombobox8
        '
        Me.Spellcombobox8.FormattingEnabled = True
        Me.Spellcombobox8.Items.AddRange(New Object() {"Flash", "Ghost", "Teleport", "Ignite", "Exhaust", "Heal", "Barrier", "Cleanse"})
        Me.Spellcombobox8.Location = New System.Drawing.Point(39, 0)
        Me.Spellcombobox8.Name = "Spellcombobox8"
        Me.Spellcombobox8.Size = New System.Drawing.Size(66, 20)
        Me.Spellcombobox8.TabIndex = 30
        '
        'Insightcheckbox8
        '
        Me.Insightcheckbox8.AutoSize = True
        Me.Insightcheckbox8.Location = New System.Drawing.Point(118, 3)
        Me.Insightcheckbox8.Name = "Insightcheckbox8"
        Me.Insightcheckbox8.Size = New System.Drawing.Size(15, 14)
        Me.Insightcheckbox8.TabIndex = 31
        Me.Insightcheckbox8.UseVisualStyleBackColor = True
        '
        'Ioniancheckbox8
        '
        Me.Ioniancheckbox8.AutoSize = True
        Me.Ioniancheckbox8.Location = New System.Drawing.Point(153, 3)
        Me.Ioniancheckbox8.Name = "Ioniancheckbox8"
        Me.Ioniancheckbox8.Size = New System.Drawing.Size(15, 14)
        Me.Ioniancheckbox8.TabIndex = 32
        Me.Ioniancheckbox8.UseVisualStyleBackColor = True
        '
        'Spellcombobox9
        '
        Me.Spellcombobox9.FormattingEnabled = True
        Me.Spellcombobox9.Items.AddRange(New Object() {"Flash", "Ghost", "Teleport", "Ignite", "Exhaust", "Heal", "Barrier", "Cleanse"})
        Me.Spellcombobox9.Location = New System.Drawing.Point(39, 26)
        Me.Spellcombobox9.Name = "Spellcombobox9"
        Me.Spellcombobox9.Size = New System.Drawing.Size(66, 20)
        Me.Spellcombobox9.TabIndex = 33
        '
        'setting2
        '
        Me.setting2.AutoSize = True
        Me.setting2.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.setting2.Location = New System.Drawing.Point(150, 19)
        Me.setting2.Name = "setting2"
        Me.setting2.Size = New System.Drawing.Size(37, 14)
        Me.setting2.TabIndex = 9
        Me.setting2.Text = "Ionian"
        '
        'setting1
        '
        Me.setting1.AutoSize = True
        Me.setting1.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.setting1.Location = New System.Drawing.Point(113, 19)
        Me.setting1.Name = "setting1"
        Me.setting1.Size = New System.Drawing.Size(40, 14)
        Me.setting1.TabIndex = 8
        Me.setting1.Text = "Insight"
        '
        'Timer2
        '
        '
        'Timer3
        '
        '
        'Timer4
        '
        '
        'Timer5
        '
        '
        'Timer6
        '
        '
        'Timer7
        '
        '
        'Timer8
        '
        '
        'Timer9
        '
        '
        'Timer10
        '
        '
        'Timer11
        '
        '
        'Timer12
        '
        '
        'Timer13
        '
        '
        'Timer14
        '
        '
        'Timer15
        '
        '
        'Timer16
        '
        '
        'Timer17
        '
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(212, 450)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents timerlabel1 As Label
    Friend WithEvents Startbutton1 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents role1 As Label
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents spellnamelabel1 As Label
    Friend WithEvents Stopbutton1 As Button
    Friend WithEvents Rewindbutton1 As Button
    Friend WithEvents Ioniancheckbox1 As CheckBox
    Friend WithEvents setting2 As Label
    Friend WithEvents setting1 As Label
    Friend WithEvents GroupBox13 As GroupBox
    Friend WithEvents spellnamelabel17 As Label
    Friend WithEvents spellnamelabel16 As Label
    Friend WithEvents Startbutton16 As Button
    Friend WithEvents Stopbutton17 As Button
    Friend WithEvents timerlabel16 As Label
    Friend WithEvents Rewindbutton17 As Button
    Friend WithEvents Rewindbutton16 As Button
    Friend WithEvents timerlabel17 As Label
    Friend WithEvents Stopbutton16 As Button
    Friend WithEvents Startbutton17 As Button
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents spellnamelabel15 As Label
    Friend WithEvents spellnamelabel14 As Label
    Friend WithEvents Stopbutton15 As Button
    Friend WithEvents Rewindbutton15 As Button
    Friend WithEvents timerlabel15 As Label
    Friend WithEvents Startbutton15 As Button
    Friend WithEvents spellnamelabel13 As Label
    Friend WithEvents Startbutton13 As Button
    Friend WithEvents Stopbutton14 As Button
    Friend WithEvents timerlabel13 As Label
    Friend WithEvents Rewindbutton14 As Button
    Friend WithEvents Rewindbutton13 As Button
    Friend WithEvents timerlabel14 As Label
    Friend WithEvents Stopbutton13 As Button
    Friend WithEvents Startbutton14 As Button
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents spellnamelabel12 As Label
    Friend WithEvents spellnamelabel11 As Label
    Friend WithEvents Stopbutton12 As Button
    Friend WithEvents Rewindbutton12 As Button
    Friend WithEvents timerlabel12 As Label
    Friend WithEvents Startbutton12 As Button
    Friend WithEvents spellnamelabel10 As Label
    Friend WithEvents Startbutton10 As Button
    Friend WithEvents Stopbutton11 As Button
    Friend WithEvents timerlabel10 As Label
    Friend WithEvents Rewindbutton11 As Button
    Friend WithEvents Rewindbutton10 As Button
    Friend WithEvents timerlabel11 As Label
    Friend WithEvents Stopbutton10 As Button
    Friend WithEvents Startbutton11 As Button
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents Role5 As Label
    Friend WithEvents spellnamelabel9 As Label
    Friend WithEvents Startbutton8 As Button
    Friend WithEvents Stopbutton9 As Button
    Friend WithEvents timerlabel8 As Label
    Friend WithEvents Rewindbutton9 As Button
    Friend WithEvents Rewindbutton8 As Button
    Friend WithEvents timerlabel9 As Label
    Friend WithEvents Stopbutton8 As Button
    Friend WithEvents Startbutton9 As Button
    Friend WithEvents spellnamelabel8 As Label
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents Role4 As Label
    Friend WithEvents spellnamelabel7 As Label
    Friend WithEvents Startbutton6 As Button
    Friend WithEvents Stopbutton7 As Button
    Friend WithEvents timerlabel6 As Label
    Friend WithEvents Rewindbutton7 As Button
    Friend WithEvents Rewindbutton6 As Button
    Friend WithEvents timerlabel7 As Label
    Friend WithEvents Stopbutton6 As Button
    Friend WithEvents Startbutton7 As Button
    Friend WithEvents spellnamelabel6 As Label
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Role3 As Label
    Friend WithEvents spellnamelabel5 As Label
    Friend WithEvents Startbutton4 As Button
    Friend WithEvents Stopbutton5 As Button
    Friend WithEvents timerlabel4 As Label
    Friend WithEvents Rewindbutton5 As Button
    Friend WithEvents Rewindbutton4 As Button
    Friend WithEvents timerlabel5 As Label
    Friend WithEvents Stopbutton4 As Button
    Friend WithEvents Startbutton5 As Button
    Friend WithEvents spellnamelabel4 As Label
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Role2 As Label
    Friend WithEvents Startbutton3 As Button
    Friend WithEvents timerlabel3 As Label
    Friend WithEvents Rewindbutton3 As Button
    Friend WithEvents Stopbutton3 As Button
    Friend WithEvents spellnamelabel3 As Label
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents spellnamelabel2 As Label
    Friend WithEvents Stopbutton2 As Button
    Friend WithEvents Rewindbutton2 As Button
    Friend WithEvents timerlabel2 As Label
    Friend WithEvents Startbutton2 As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Spellcombobox1 As ComboBox
    Friend WithEvents Insightcheckbox1 As CheckBox
    Friend WithEvents Spellcombobox2 As ComboBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Spellcombobox3 As ComboBox
    Friend WithEvents Insightcheckbox3 As CheckBox
    Friend WithEvents Ioniancheckbox3 As CheckBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Spellcombobox4 As ComboBox
    Friend WithEvents Insightcheckbox4 As CheckBox
    Friend WithEvents Ioniancheckbox4 As CheckBox
    Friend WithEvents Spellcombobox5 As ComboBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Spellcombobox6 As ComboBox
    Friend WithEvents Insightcheckbox6 As CheckBox
    Friend WithEvents Ioniancheckbox6 As CheckBox
    Friend WithEvents Spellcombobox7 As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Spellcombobox8 As ComboBox
    Friend WithEvents Insightcheckbox8 As CheckBox
    Friend WithEvents Ioniancheckbox8 As CheckBox
    Friend WithEvents Spellcombobox9 As ComboBox
    Friend WithEvents Ioniancheckbox2 As CheckBox
    Friend WithEvents Insightcheckbox2 As CheckBox
    Friend WithEvents Insightcheckbox5 As CheckBox
    Friend WithEvents Ioniancheckbox5 As CheckBox
    Friend WithEvents Insightcheckbox7 As CheckBox
    Friend WithEvents Ioniancheckbox7 As CheckBox
    Friend WithEvents Insightcheckbox9 As CheckBox
    Friend WithEvents Ioniancheckbox9 As CheckBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer3 As Timer
    Friend WithEvents Timer4 As Timer
    Friend WithEvents Timer5 As Timer
    Friend WithEvents Timer6 As Timer
    Friend WithEvents Timer7 As Timer
    Friend WithEvents Timer8 As Timer
    Friend WithEvents Timer9 As Timer
    Friend WithEvents Timer10 As Timer
    Friend WithEvents Timer11 As Timer
    Friend WithEvents Timer12 As Timer
    Friend WithEvents Timer13 As Timer
    Friend WithEvents Timer14 As Timer
    Friend WithEvents Timer15 As Timer
    Friend WithEvents Timer16 As Timer
    Friend WithEvents Timer17 As Timer
End Class
